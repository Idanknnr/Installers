@echo off
title Windows 11 Action Menu
color 0B

:MENU
cls
echo ==============================================
echo  Windows 11 Action Menu
echo ==============================================
echo  1. Shutdown
echo  2. Restart
echo  3. Firmware
echo  4. Test Choice
echo ==============================================

choice /c:1234 /n /m "Enter your choice (1-4): "

if errorlevel 4 goto TEST
if errorlevel 3 goto GOTO
if errorlevel 2 goto RESTART
if errorlevel 1 goto SHUTDOWN

:SHUTDOWN
cls
shutdown /s /f /t 0

pause
goto MENU

:RESTART
cls
shutdown /r /f /t 0

pause
goto MENU

:GOTO
cls
shutdown /r /fw /f /t 0

pause
goto MENU

:TEST
cls
echo test

pause
goto MENU
